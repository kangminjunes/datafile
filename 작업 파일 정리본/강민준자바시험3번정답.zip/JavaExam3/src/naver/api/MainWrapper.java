package naver.api;

public class MainWrapper {

  public static void main(String[] args) {
    
    NaverApiSearchBook app = new NaverApiSearchBook();
    app.getSearchList();
    
  }

}
