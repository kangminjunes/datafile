package parking;

public class ParkingLotMain {

  public static void main(String[] args) {
    
    ParkingLot parkingLot = new ParkingLot("대박주차장");
    parkingLot.manage();

  }
}
